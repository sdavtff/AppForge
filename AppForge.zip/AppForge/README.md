# AppForge

App Android que usa a API do OpenRouter para gerar apps (HTML/CSS/JS em um arquivo) a partir de uma descrição, com prévia na própria tela.

## Como gerar o APK

**Opção 1 – GitHub Actions (mais fácil, sem PC):**
1. Crie um repositório no GitHub e envie esta pasta.
2. Vá em *Actions → Build APK → Run workflow*.
3. Baixe o artefato `AppForge-debug-apk`, extraia e instale no celular.

**Opção 2 – Android Studio:** abra a pasta e rode *Build → Build APK(s)*.

## Como usar
1. Abra o app e cole sua chave do OpenRouter (fica guardada criptografada).
2. Escolha o modelo (ex.: `anthropic/claude-sonnet-4.5`).
3. Descreva o app e toque em **Gerar app**.
4. Use **Salvar / compartilhar HTML** para guardar o resultado.

## Próximos passos
- Empacotar o HTML gerado em um APK (via Termux ou GitHub Actions).
- Histórico de conversas e refinamento ("mude a cor do botão").
- Suporte a projetos Kotlin com compilação remota.

package com.example.appforge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var keyInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var promptInput: EditText
    private lateinit var status: TextView
    private lateinit var web: WebView
    private var lastHtml: String = ""

    private val systemPrompt = """
        Você é um gerador de apps. Responda SOMENTE com um único arquivo HTML completo
        (HTML + CSS + JavaScript inline, sem dependências externas), dentro de um bloco ```html.
        O app deve funcionar offline, ser responsivo e ter boa aparência em celular.
    """.trimIndent()

    private fun prefs() = EncryptedSharedPreferences.create(
        this,
        "appforge_secure",
        MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        keyInput = EditText(this).apply {
            hint = "Chave da API do OpenRouter (sk-or-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs().getString("api_key", ""))
        }
        modelInput = EditText(this).apply {
            hint = "Modelo (ex.: anthropic/claude-sonnet-4.5)"
            setText(prefs().getString("model", "anthropic/claude-sonnet-4.5"))
        }
        promptInput = EditText(this).apply {
            hint = "Descreva o app que quer criar"
            minLines = 3
        }
        val generate = Button(this).apply { text = "Gerar app" }
        val share = Button(this).apply { text = "Salvar / compartilhar HTML" }
        status = TextView(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        listOf(keyInput, modelInput, promptInput, generate, share, status, web)
            .forEach { root.addView(it) }
        setContentView(root)

        generate.setOnClickListener { generateApp() }
        share.setOnClickListener { shareHtml() }
    }

    private fun generateApp() {
        val key = keyInput.text.toString().trim()
        val model = modelInput.text.toString().trim()
        val request = promptInput.text.toString().trim()
        if (key.isEmpty() || model.isEmpty() || request.isEmpty()) {
            Toast.makeText(this, "Preencha chave, modelo e descrição", Toast.LENGTH_SHORT).show()
            return
        }
        prefs().edit().putString("api_key", key).putString("model", model).apply()
        status.text = "Gerando..."

        thread {
            try {
                val html = callOpenRouter(key, model, request)
                runOnUiThread {
                    lastHtml = html
                    web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                    status.text = "Pronto! Prévia abaixo."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Erro: ${e.message}" }
            }
        }
    }

    private fun callOpenRouter(key: String, model: String, request: String): String {
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt))
                put(JSONObject().put("role", "user").put("content", request))
            })
        }
        val conn = URL("https://openrouter.ai/api/v1/chat/completions")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30_000
        conn.readTimeout = 180_000
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $key")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(200)}")

        val content = JSONObject(text)
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
        return extractHtml(content)
    }

    private fun extractHtml(content: String): String {
        val match = Regex("```(?:html)?\\s*([\\s\\S]*?)```").find(content)
        return (match?.groupValues?.get(1) ?: content).trim()
    }

    private fun shareHtml() {
        if (lastHtml.isEmpty()) {
            Toast.makeText(this, "Gere um app primeiro", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(getExternalFilesDir(null), "app_gerado.html")
        file.writeText(lastHtml)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            putExtra(Intent.EXTRA_TEXT, lastHtml)
        }
        startActivity(Intent.createChooser(send, "Compartilhar HTML"))
        Toast.makeText(this, "Salvo em ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }
}
